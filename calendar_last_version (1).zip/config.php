<?php
/* add your own credentials */
$dbhost = "localhost";
$dbuser = "root";
$dbpass = "root";
$dbname = "calendardb";
